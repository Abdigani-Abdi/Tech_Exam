package com.testCases;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.pageObjects.Landing_Page;
import com.pageObjects.Login_Page;

public class TestCases extends Base_Class
{
		
		@Test(priority=1,dataProvider="data")
		public void loginTest_001(String uname,String pwd)
		{
			Landing_Page lp=new Landing_Page(driver); 
			lp.clickFormAuth();
		
			
			Login_Page lop=new Login_Page(driver);
			lop.setUserName(uname);
			lop.setpassword(pwd);
			lop.clicklogin();
			
			//Assertions
			SoftAssert soft=new SoftAssert();
			String expected=driver.findElement(By.id("flash")).getText();
			soft.assertEquals(true, expected.contains("is invalid!"));
			
			System.out.println("Validity of the  Login:" +expected);
			
			driver.navigate().back();
			driver.navigate().back();
		}
		@DataProvider(name="data")
		public Object [][] getData() 
		{
			Object [][]data=new Object[3][2];
			data[0][0]="tomsmith";
			data[0][1]="SuperSecretPassword123";
			data[1][0]="tomsmith123";
			data[1][1]="SuperSecretPassword!";
			data[2][0]="tomsmith";
			data[2][1]="SuperSecretPassword!";
			return data;
		}
		@Test(priority=2)
		public void infinteScroll_002()  
		{
			Landing_Page lp=new Landing_Page(driver);
			lp.clickInfiniteScroll();
		
			
			JavascriptExecutor js=((JavascriptExecutor)driver);
			js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
			
			js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
			
			js.executeScript("window.scrollTo(document.body.scrollHeight,0)");
			//Assertions 
			String expected=driver.findElement(By.xpath("//*[@id=\"content\"]/div/h3")).getText();
			String actual="Infinite Scroll";
			Assert.assertEquals(actual, expected);
			
			System.out.println("InfiniteScroll text is:" +expected);
			driver.navigate().back();
		}
		@Test(priority=3)
		public void keyPresses_003() 
		{	  
			Landing_Page lp=new Landing_Page(driver);
			lp.clickKeyPresses();
			
			Actions act=new Actions(driver);
			
			act.sendKeys(Keys.ENTER).build().perform();
			//Assertions
			String expected1=driver.findElement(By.id("result")).getText();
			String actual1="You entered: ENTER";
			Assert.assertEquals(actual1, expected1);
			System.out.println("KeyPress ENTER message is:" +expected1);
			
			act.sendKeys(Keys.ESCAPE).build().perform();
			//Assertions
			String expected2=driver.findElement(By.id("result")).getText();
			String actual2="You entered: ESCAPE";
			Assert.assertEquals(actual2, expected2);
			System.out.println("KeyPress ESCAPE message is:" +expected2);
			
			act.sendKeys(Keys.TAB).build().perform();
			//Assertions
			String expected3=driver.findElement(By.id("result")).getText();
			String actual3="You entered: TAB";
			Assert.assertEquals(actual3, expected3);
			System.out.println("KeyPress TAB message is:" +expected3);
			
			act.sendKeys(Keys.ALT).build().perform();
			//Assertions
			String expected4=driver.findElement(By.id("result")).getText();
			String actual4="You entered: ALT";
			Assert.assertEquals(actual4, expected4);
			System.out.println("KeyPress ALT message is:" +expected4);
		}

}
